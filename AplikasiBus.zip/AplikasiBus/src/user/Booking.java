/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package user;

import java.io.BufferedWriter;
import java.io.FileWriter;
import javax.swing.JOptionPane;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

/**
 *
 * @author niawdr
 */
public class Booking extends javax.swing.JFrame {
String jam, pay;
    /**
     * Creates new form Booking
     */
    String kelas, cetak;
    //private LocalDateTime time1;
    public Booking() {
        initComponents();
        curDateTime();
    }
    
    //menampilkan waktu
    public void curDateTime(){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
        LocalDateTime time = LocalDateTime.now();    
        dateTime.setText(dtf.format(time));
    }
    
    
    //method untuk menentukan harga tiket berdasarkan kelas
    public void harga(){
        
        if(rbEco.isSelected()){
            txtPrice.setText("");
            if(cbCode.getSelectedItem().equals("Choose")){
            }
                if(cbCode.getSelectedItem().equals("LOR102")){
                    if(cbSeat.getSelectedItem().equals("1 Seat")){
                        txtPrice.setText("50000");
                    }
                    if(cbSeat.getSelectedItem().equals("2 Seat")){
                        txtPrice.setText("100000");
                    }
                    if(cbSeat.getSelectedItem().equals("3 Seat")){
                        txtPrice.setText("150000");
                    }
                    if(cbSeat.getSelectedItem().equals("4 Seat")){
                        txtPrice.setText("200000");
                    }
                }
                if(cbCode.getSelectedItem().equals("SAF202")){
                    if(cbSeat.getSelectedItem().equals("1 Seat")){
                        txtPrice.setText("65000");
                    }
                    if(cbSeat.getSelectedItem().equals("2 Seat")){
                        txtPrice.setText("130000");
                    }
                    if(cbSeat.getSelectedItem().equals("3 Seat")){
                        txtPrice.setText("195000");
                    }
                    if(cbSeat.getSelectedItem().equals("4 Seat")){
                        txtPrice.setText("260000");
                    }
                }
                if(cbCode.getSelectedItem().equals("GHA302")){
                    if(cbSeat.getSelectedItem().equals("1 Seat")){
                        txtPrice.setText("70000");
                    }
                    if(cbSeat.getSelectedItem().equals("2 Seat")){
                        txtPrice.setText("140000");
                    }
                    if(cbSeat.getSelectedItem().equals("3 Seat")){
                        txtPrice.setText("210000");
                    }
                    if(cbSeat.getSelectedItem().equals("4 Seat")){
                        txtPrice.setText("280000");
                    }
                }
        }    
                
        if(rbExe.isSelected()){
            txtPrice.setText("");
            if(cbCode.getSelectedItem().equals("Choose")){
            }
                if(cbCode.getSelectedItem().equals("LOR102")){
                    if(cbSeat.getSelectedItem().equals("1 Seat")){
                        txtPrice.setText("150000");
                    }
                    if(cbSeat.getSelectedItem().equals("2 Seat")){
                        txtPrice.setText("300000");
                    }
                    if(cbSeat.getSelectedItem().equals("3 Seat")){
                        txtPrice.setText("450000");
                    }
                    if(cbSeat.getSelectedItem().equals("4 Seat")){
                        txtPrice.setText("600000");
                    }
                }
                if(cbCode.getSelectedItem().equals("SAF202")){
                    if(cbSeat.getSelectedItem().equals("1 Seat")){
                        txtPrice.setText("165000");
                    }
                    if(cbSeat.getSelectedItem().equals("2 Seat")){
                        txtPrice.setText("330000");
                    }
                    if(cbSeat.getSelectedItem().equals("3 Seat")){
                        txtPrice.setText("495000");
                    }
                    if(cbSeat.getSelectedItem().equals("4 Seat")){
                        txtPrice.setText("660000");
                    }
                }
                if(cbCode.getSelectedItem().equals("GHA302")){
                    if(cbSeat.getSelectedItem().equals("1 Seat")){
                        txtPrice.setText("170000");
                    }
                    if(cbSeat.getSelectedItem().equals("2 Seat")){
                        txtPrice.setText("340000");
                    }
                    if(cbSeat.getSelectedItem().equals("3 Seat")){
                        txtPrice.setText("510000");
                    }
                    if(cbSeat.getSelectedItem().equals("4 Seat")){
                        txtPrice.setText("680000");
                    }
                }
        }
            
    }
    
        
    //method untuk mencetak tiket
    public void cetak(){
        
        int jawab;
        
        jawab = JOptionPane.showConfirmDialog(rootPane, "Print Ticket?", "Message", 
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        
        if(jawab==JOptionPane.YES_OPTION){
            
            //jam
            if(rbJam1.isSelected()){
                jam = rbJam1.getText();
            }
            else if(rbJam2.isSelected()){
                jam = rbJam2.getText();
            }
            else if(rbJam3.isSelected()){
                jam = rbJam3.getText();
            }
            
            //kelas
            if(rbEco.isSelected()){
                kelas=rbEco.getText();
            }   
            if(rbExe.isSelected()){
                kelas=rbExe.getText();
            }
            
            //payment
            if(rbCash.isSelected()){
                pay=rbCash.getText();
            }   
            if(rbDebit.isSelected()){
                pay=rbDebit.getText();
            }
            
            cetak=" Name : " +txtName.getText() +
               "\n Bus Code : " +cbCode.getSelectedItem() +
               "\n Bus : " +txtBus.getText() +
               "\n Destination : " +txtDest.getText() +
               "\n Seat : " +cbSeat.getSelectedItem() +
               "\n Date : " +cbDate.getSelectedItem() +" "+cbMonth.getSelectedItem() +" "+cbYear.getSelectedItem() +
               "\n Departure Time : " + jam +
               "\n Class : " +kelas +
               "\n Price : Rp " +txtPrice.getText() +
               "\n Payment : " +pay;
            
            JOptionPane.showMessageDialog(rootPane, cetak, "Ticket Booking Data", JOptionPane.INFORMATION_MESSAGE);
        }
        
        if(jawab==JOptionPane.NO_OPTION){
            JOptionPane.showMessageDialog(rootPane, "Please check again.");
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgJam = new javax.swing.ButtonGroup();
        bgKelas = new javax.swing.ButtonGroup();
        bgBayar = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        cbCode = new javax.swing.JComboBox<>();
        txtBus = new javax.swing.JTextField();
        txtDest = new javax.swing.JTextField();
        cbSeat = new javax.swing.JComboBox<>();
        rbJam1 = new javax.swing.JRadioButton();
        rbJam3 = new javax.swing.JRadioButton();
        rbJam2 = new javax.swing.JRadioButton();
        rbExe = new javax.swing.JRadioButton();
        rbEco = new javax.swing.JRadioButton();
        txtPrice = new javax.swing.JTextField();
        cbDate = new javax.swing.JComboBox<>();
        cbMonth = new javax.swing.JComboBox<>();
        cbYear = new javax.swing.JComboBox<>();
        btnPrint = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        rbCash = new javax.swing.JRadioButton();
        rbDebit = new javax.swing.JRadioButton();
        dateTime = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));

        jLabel1.setFont(new java.awt.Font("Bebas Neue Bold", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("BOOKING TICKET");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Montserrat", 0, 15)); // NOI18N
        jLabel2.setText("Bus Code");

        jLabel3.setFont(new java.awt.Font("Montserrat", 0, 15)); // NOI18N
        jLabel3.setText("Name");

        txtName.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Montserrat", 0, 15)); // NOI18N
        jLabel4.setText("Bus");

        jLabel5.setFont(new java.awt.Font("Montserrat", 0, 15)); // NOI18N
        jLabel5.setText("Seat");

        jLabel6.setFont(new java.awt.Font("Montserrat", 0, 15)); // NOI18N
        jLabel6.setText("Destination");

        jLabel7.setFont(new java.awt.Font("Montserrat", 0, 15)); // NOI18N
        jLabel7.setText("Date");

        jLabel8.setFont(new java.awt.Font("Montserrat", 0, 15)); // NOI18N
        jLabel8.setText("Departure Time");

        jLabel9.setFont(new java.awt.Font("Montserrat", 0, 15)); // NOI18N
        jLabel9.setText("Price");

        jLabel10.setFont(new java.awt.Font("Montserrat", 0, 15)); // NOI18N
        jLabel10.setText("Class Ticket");

        cbCode.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        cbCode.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose", "LOR102", "SAF202", "GHA302" }));
        cbCode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbCodeActionPerformed(evt);
            }
        });

        txtBus.setEditable(false);
        txtBus.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N

        txtDest.setEditable(false);
        txtDest.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N

        cbSeat.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        cbSeat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose", "1 Seat", "2 Seat", "3 Seat", "4 Seat" }));
        cbSeat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbSeatActionPerformed(evt);
            }
        });

        bgJam.add(rbJam1);
        rbJam1.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        rbJam1.setText("09.00");
        rbJam1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                rbJam1StateChanged(evt);
            }
        });
        rbJam1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbJam1ActionPerformed(evt);
            }
        });

        bgJam.add(rbJam3);
        rbJam3.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        rbJam3.setText("19.00");
        rbJam3.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentHidden(java.awt.event.ComponentEvent evt) {
                rbJam3ComponentHidden(evt);
            }
        });

        bgJam.add(rbJam2);
        rbJam2.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        rbJam2.setText("13.00");
        rbJam2.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                rbJam2StateChanged(evt);
            }
        });

        bgKelas.add(rbExe);
        rbExe.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        rbExe.setText("Executive");
        rbExe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbExeActionPerformed(evt);
            }
        });

        bgKelas.add(rbEco);
        rbEco.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        rbEco.setText("Economy");
        rbEco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbEcoActionPerformed(evt);
            }
        });

        txtPrice.setEditable(false);
        txtPrice.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N

        cbDate.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        cbDate.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Date", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

        cbMonth.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        cbMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Month", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" }));

        cbYear.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        cbYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Year", "2022" }));

        btnPrint.setBackground(new java.awt.Color(0, 0, 102));
        btnPrint.setFont(new java.awt.Font("Montserrat", 1, 12)); // NOI18N
        btnPrint.setForeground(new java.awt.Color(255, 255, 255));
        btnPrint.setText("PRINT TICKET");
        btnPrint.setBorder(null);
        btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintActionPerformed(evt);
            }
        });

        btnClear.setBackground(new java.awt.Color(0, 0, 102));
        btnClear.setFont(new java.awt.Font("Montserrat", 1, 12)); // NOI18N
        btnClear.setForeground(new java.awt.Color(255, 255, 255));
        btnClear.setText("CLEAR");
        btnClear.setBorder(null);
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        btnBack.setBackground(new java.awt.Color(51, 102, 0));
        btnBack.setFont(new java.awt.Font("Bahnschrift", 1, 10)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.setBorder(null);
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        btnExit.setBackground(new java.awt.Color(255, 51, 51));
        btnExit.setFont(new java.awt.Font("Bahnschrift", 1, 10)); // NOI18N
        btnExit.setForeground(new java.awt.Color(255, 255, 255));
        btnExit.setText("EXIT");
        btnExit.setBorder(null);
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Montserrat", 0, 15)); // NOI18N
        jLabel11.setText("Payment");

        bgBayar.add(rbCash);
        rbCash.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        rbCash.setText("Cash");

        bgBayar.add(rbDebit);
        rbDebit.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        rbDebit.setText("Debit");

        dateTime.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        dateTime.setText("jLabel12");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel3)
                        .addComponent(jLabel9)
                        .addComponent(jLabel4)
                        .addComponent(jLabel2)
                        .addComponent(jLabel5)
                        .addComponent(jLabel6)
                        .addComponent(jLabel7)
                        .addComponent(jLabel8)
                        .addComponent(jLabel10)
                        .addComponent(jLabel11))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(82, 82, 82)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(95, 95, 95)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(cbDate, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(35, 35, 35)
                                        .addComponent(cbMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(txtPrice, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                            .addComponent(rbEco)
                                            .addGap(38, 38, 38)
                                            .addComponent(rbExe)))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(rbCash)
                                        .addGap(38, 38, 38)
                                        .addComponent(rbDebit))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(rbJam1)
                                        .addGap(38, 38, 38)
                                        .addComponent(rbJam2)
                                        .addGap(40, 40, 40)
                                        .addComponent(rbJam3)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                                .addComponent(cbYear, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtName)
                                        .addComponent(cbCode, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(txtBus)
                                        .addComponent(txtDest, javax.swing.GroupLayout.DEFAULT_SIZE, 437, Short.MAX_VALUE)
                                        .addComponent(cbSeat, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(dateTime, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addGap(68, 68, 68))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrint, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(263, 263, 263))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(dateTime, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cbCode, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtBus, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtDest, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cbSeat, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cbDate, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbYear, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(rbJam1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rbJam3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rbJam2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(rbEco, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rbExe, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(rbCash, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rbDebit, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnPrint, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(47, 47, 47))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28))))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrintActionPerformed
        // TODO add your handling code here:
        
        /*if(txtName.getText().equals("")  || cbCode.getSelectedItem().equals("") || txtBus.getText().equals("") || 
                txtDest.getText().equals("")  || cbSeat.getSelectedItem().equals("")  || cbDate.getSelectedItem().equals("") ||
                cbMonth.getSelectedItem().equals("")  || cbYear.getSelectedItem().equals("")  || jam.equals("") || kelas.equals("") ||
                txtPrice.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "Please fill in the blank!");
        }else{
            cetak();
        }*/
        
        cetak();
        
        try{
                String file = "src/database/tiket.txt";
                String name=txtName.getText();
                String code=String.valueOf(cbCode.getSelectedItem());
                String bus=txtBus.getText();
                String dest=txtDest.getText();
                String seat=String.valueOf(cbSeat.getSelectedItem());
                String date=String.valueOf(cbDate.getSelectedItem());
                String month=String.valueOf(cbMonth.getSelectedItem());
                String year=String.valueOf(cbYear.getSelectedItem());
                String time=jam;
                String kls=kelas;
                String price=txtPrice.getText();
                String payment=pay;
                
            BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
            bw.write(name + ","+ code + ","+ bus + ","+ dest +","+ seat +","+ date+" " + month+" " + year+" " +","+ time +","+ kls +","+ price+","+ payment);
            bw.flush();
            bw.newLine();
            bw.close();
            System.out.println("Data saved succesfully!");
            
        }catch (Exception e){
            System.out.println("Data was not saved!");
        }
    }//GEN-LAST:event_btnPrintActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        // TODO add your handling code here:
        Dashboard dash=new Dashboard();
        dash.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void cbCodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbCodeActionPerformed
        // TODO add your handling code here:
        //kondisi untuk menentukan nama bus dan tujuan
        if(cbCode.getSelectedItem().equals("Choose")){
        }
        
        if(cbCode.getSelectedItem().equals("LOR102")){
            txtBus.setText("Lorena");
            txtDest.setText("Denpasar - Singaraja");
        }
        
        if(cbCode.getSelectedItem().equals("SAF202")){
            txtBus.setText("Safari");
            txtDest.setText("Gianyar - Negara");
        }
        
        if(cbCode.getSelectedItem().equals("GHA302")){
            txtBus.setText("Gunung Harta");
            txtDest.setText("Jimbaran - Kintamani");
        }
    }//GEN-LAST:event_cbCodeActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        // TODO add your handling code here:
        //memanggil method clear
        clear();
    }//GEN-LAST:event_btnClearActionPerformed

    private void rbEcoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbEcoActionPerformed
        // TODO add your handling code here:
        harga();
    }//GEN-LAST:event_rbEcoActionPerformed

    private void rbExeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbExeActionPerformed
        // TODO add your handling code here:
        harga();
    }//GEN-LAST:event_rbExeActionPerformed

    private void cbSeatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSeatActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_cbSeatActionPerformed

    private void rbJam1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbJam1ActionPerformed
    
    }//GEN-LAST:event_rbJam1ActionPerformed

    private void rbJam1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_rbJam1StateChanged
    LocalDateTime time = LocalDateTime.now(); 
    String jam = time.toString();
    //int waktu = Integer.parseInt(jam);
    String jam2 = "13:00:01";
    System.out.println(jam);
    //LocalDateTime time2 = LocalDateTime.parse( "09:00:00" );
    
    if(jam.compareTo(jam2) > 0){
        rbJam1.setEnabled(false);
    }else {
        rbJam1.setEnabled(true);
    }
    }//GEN-LAST:event_rbJam1StateChanged

    private void rbJam2StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_rbJam2StateChanged

    }//GEN-LAST:event_rbJam2StateChanged

    private void rbJam3ComponentHidden(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_rbJam3ComponentHidden
    
    }//GEN-LAST:event_rbJam3ComponentHidden

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Booking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Booking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Booking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Booking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Booking().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup bgBayar;
    private javax.swing.ButtonGroup bgJam;
    private javax.swing.ButtonGroup bgKelas;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnPrint;
    private javax.swing.JComboBox<String> cbCode;
    private javax.swing.JComboBox<String> cbDate;
    private javax.swing.JComboBox<String> cbMonth;
    private javax.swing.JComboBox<String> cbSeat;
    private javax.swing.JComboBox<String> cbYear;
    private javax.swing.JLabel dateTime;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JRadioButton rbCash;
    private javax.swing.JRadioButton rbDebit;
    private javax.swing.JRadioButton rbEco;
    private javax.swing.JRadioButton rbExe;
    private javax.swing.JRadioButton rbJam1;
    private javax.swing.JRadioButton rbJam2;
    private javax.swing.JRadioButton rbJam3;
    private javax.swing.JTextField txtBus;
    private javax.swing.JTextField txtDest;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPrice;
    // End of variables declaration//GEN-END:variables

    public void clear(){
    txtName.setText("");
    cbCode.setSelectedItem("Choose");
    txtBus.setText("");
    txtDest.setText("");
    cbDate.setSelectedItem("Date");
    cbMonth.setSelectedItem("Month");
    cbYear.setSelectedItem("Year");
    bgJam.clearSelection();
    bgKelas.clearSelection();
    txtPrice.setText("");
    JOptionPane.showMessageDialog(rootPane, "Data has been deleted.");
    }


}